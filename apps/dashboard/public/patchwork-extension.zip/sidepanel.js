"use strict";
(() => {
  // src/messages.ts
  var isRecord = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
  function normalizeAnchor(raw) {
    if (!isRecord(raw) || typeof raw.cssSelector !== "string") return null;
    const str = (v) => typeof v === "string" ? v : "";
    if (raw.cssSelector === "" && str(raw.xpath) === "") return null;
    return {
      cssSelector: raw.cssSelector,
      xpath: str(raw.xpath),
      textContent: str(raw.textContent),
      attributes: isRecord(raw.attributes) ? Object.fromEntries(Object.entries(raw.attributes).filter((e) => typeof e[1] === "string")) : {},
      parentContext: str(raw.parentContext),
      siblingContext: Array.isArray(raw.siblingContext) ? raw.siblingContext.filter((x) => typeof x === "string") : []
    };
  }
  function normalizePick(raw) {
    if (!isRecord(raw)) return null;
    const anchor = normalizeAnchor(raw.anchor);
    if (!anchor || typeof raw.tag !== "string" || typeof raw.pageUrl !== "string" || typeof raw.pickedAt !== "number") return null;
    return { anchor, tag: raw.tag, pageUrl: raw.pageUrl, pickedAt: raw.pickedAt };
  }
  async function send(message) {
    const reply = await chrome.runtime.sendMessage(message);
    if (!reply) throw new Error("The Patchwork background worker did not reply. Reload the extension and the page.");
    if (!reply.ok) throw new Error(reply.error);
    return reply.data;
  }

  // src/sidepanel/index.ts
  var CHECK_EVERY_MS = 5e3;
  function el(id) {
    const node = document.getElementById(id);
    if (!node) throw new Error(`Side panel is missing #${id}`);
    return node;
  }
  var dot = el("conn-dot");
  var connText = el("conn-text");
  var connHint = el("conn-hint");
  var recheck = el("conn-recheck");
  var form = el("settings-form");
  var serverUrlInput = el("serverUrl");
  var authorIdInput = el("authorId");
  var saveButton = el("settings-save");
  var settingsMsg = el("settings-msg");
  function renderStatus(status) {
    if (!status) {
      dot.dataset.state = "checking";
      connText.textContent = "Checking connection...";
      connHint.textContent = "";
      return;
    }
    dot.dataset.state = status.state;
    if (status.state === "connected") {
      connText.textContent = `Connected to ${status.serverUrl}`;
      connHint.textContent = `Data store: ${status.store}`;
    } else {
      connText.textContent = `Not connected: ${status.error}`;
      connHint.textContent = 'Start it with "npm run demo", or fix the Server URL below.';
    }
  }
  function renderBackgroundFailure(err) {
    dot.dataset.state = "offline";
    connText.textContent = `Extension background worker problem: ${err instanceof Error ? err.message : String(err)}`;
    connHint.textContent = "Reload the extension at chrome://extensions, then reopen this panel.";
  }
  var checking = false;
  async function runCheck() {
    if (checking) return;
    checking = true;
    recheck.disabled = true;
    try {
      renderStatus(await send({ type: "CHECK_CONNECTION" }));
    } catch (err) {
      renderBackgroundFailure(err);
    } finally {
      checking = false;
      recheck.disabled = false;
    }
  }
  function showMessage(kind, text) {
    settingsMsg.dataset.kind = kind;
    settingsMsg.textContent = text;
  }
  recheck.addEventListener("click", () => void runCheck());
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    void (async () => {
      saveButton.disabled = true;
      showMessage("", "");
      try {
        const saved = await send({
          type: "SET_SETTINGS",
          settings: { serverUrl: serverUrlInput.value, authorId: authorIdInput.value }
        });
        serverUrlInput.value = saved.serverUrl;
        authorIdInput.value = saved.authorId;
        showMessage("ok", "Saved.");
        renderStatus(null);
        void runCheck();
      } catch (err) {
        showMessage("error", err instanceof Error ? err.message : String(err));
      } finally {
        saveButton.disabled = false;
      }
    })();
  });
  var pickButton = el("pick-start");
  var pickMsg = el("pick-msg");
  var pickCard = el("pick-card");
  function renderPick(pick) {
    pickCard.hidden = !pick;
    if (!pick) return;
    el("pick-selector").textContent = pick.anchor.cssSelector;
    el("pick-text").textContent = pick.anchor.textContent || "(no text)";
    el("pick-parent").textContent = pick.anchor.parentContext || "(none)";
    el("pick-siblings").textContent = pick.anchor.siblingContext.join(", ") || "(none)";
    el("pick-page").textContent = pick.pageUrl;
    pickMsg.dataset.kind = "";
    pickMsg.textContent = `Picked <${pick.tag}>.`;
  }
  async function sendToActiveTab(message) {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab?.id === void 0) throw new Error("No active tab.");
    try {
      await chrome.tabs.sendMessage(tab.id, message);
    } catch {
      throw new Error("Cannot pick on this page. Reload the page (content scripts load only when a page loads), and note that chrome:// pages and the Web Store are off limits.");
    }
  }
  pickButton.addEventListener("click", () => {
    void (async () => {
      try {
        await sendToActiveTab({ type: "START_PICKER" });
        pickMsg.dataset.kind = "";
        pickMsg.textContent = "Click an element on the page. Esc cancels.";
      } catch (err) {
        pickMsg.dataset.kind = "error";
        pickMsg.textContent = err instanceof Error ? err.message : String(err);
      }
    })();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "session" && changes.lastPick) renderPick(normalizePick(changes.lastPick.newValue));
  });
  async function init() {
    try {
      const settings = await send({ type: "GET_SETTINGS" });
      serverUrlInput.value = settings.serverUrl;
      authorIdInput.value = settings.authorId;
      renderStatus(await send({ type: "GET_CONNECTION_STATUS" }));
      renderPick(await send({ type: "GET_LAST_PICK" }));
    } catch (err) {
      renderBackgroundFailure(err);
      return;
    }
    await runCheck();
    setInterval(() => {
      if (document.visibilityState === "visible") void runCheck();
    }, CHECK_EVERY_MS);
  }
  void init();
})();
//# sourceMappingURL=sidepanel.js.map
