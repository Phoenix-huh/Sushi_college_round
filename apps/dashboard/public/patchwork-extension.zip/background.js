"use strict";
(() => {
  // src/messages.ts
  var isRecord = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
  var validators = {
    GET_SETTINGS: () => true,
    SET_SETTINGS: (m) => isRecord(m.settings),
    CHECK_CONNECTION: () => true,
    GET_CONNECTION_STATUS: () => true,
    GET_LIVE_PATCHES: () => true,
    PICK_RESULT: (m) => isRecord(m.pick),
    GET_LAST_PICK: () => true,
    GET_BASE_VERSION: () => true,
    SAVE_DRAFT: (m) => typeof m.target_url === "string" && typeof m.base_version === "number" && isRecord(m.anchors) && isRecord(m.change) && typeof m.change.type === "string" && typeof m.change.value === "string" && (m.title === void 0 || typeof m.title === "string")
  };
  function parseMessage(raw) {
    if (!isRecord(raw) || typeof raw.type !== "string") return null;
    if (!Object.hasOwn(validators, raw.type)) return null;
    if (!validators[raw.type](raw)) return null;
    return raw;
  }
  function normalizeAnchor(raw) {
    if (!isRecord(raw) || typeof raw.cssSelector !== "string") return null;
    const str = (v) => typeof v === "string" ? v : "";
    if (raw.cssSelector === "" && str(raw.xpath) === "") return null;
    return {
      cssSelector: raw.cssSelector,
      xpath: str(raw.xpath),
      textContent: str(raw.textContent),
      attributes: isRecord(raw.attributes) ? Object.fromEntries(Object.entries(raw.attributes).filter((e) => typeof e[1] === "string")) : {},
      parentContext: str(raw.parentContext),
      siblingContext: Array.isArray(raw.siblingContext) ? raw.siblingContext.filter((x) => typeof x === "string") : []
    };
  }
  function normalizePick(raw) {
    if (!isRecord(raw)) return null;
    const anchor = normalizeAnchor(raw.anchor);
    if (!anchor || typeof raw.tag !== "string" || typeof raw.pageUrl !== "string" || typeof raw.pickedAt !== "number") return null;
    return { anchor, tag: raw.tag, pageUrl: raw.pageUrl, pickedAt: raw.pickedAt };
  }
  function isConnectionStatus(v) {
    if (!isRecord(v)) return false;
    if (typeof v.serverUrl !== "string" || typeof v.checkedAt !== "number") return false;
    if (v.state === "connected") return typeof v.store === "string";
    if (v.state === "offline") return typeof v.error === "string";
    return false;
  }

  // src/settings.ts
  var DEFAULT_SETTINGS = {
    serverUrl: "http://localhost:4000",
    authorId: "00000000-0000-0000-0000-000000000001"
  };
  function chromeStore(area) {
    return {
      get: async (keys) => await area.get(keys),
      set: async (items) => {
        await area.set(items);
      }
    };
  }
  var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  var SettingsError = class extends Error {
  };
  function normalizeServerUrl(input) {
    const text = input.trim();
    let url;
    try {
      url = new URL(text);
    } catch {
      throw new SettingsError("Server URL is not a valid URL. Example: http://localhost:4000");
    }
    if (url.protocol !== "http:" && url.protocol !== "https:") {
      throw new SettingsError("Server URL must start with http:// or https://");
    }
    return url.origin;
  }
  function normalizeAuthorId(input) {
    const text = input.trim();
    if (!UUID.test(text)) throw new SettingsError("Author id must be a UUID, like 00000000-0000-0000-0000-000000000001");
    return text.toLowerCase();
  }
  function mergeSettings(current, update) {
    return {
      serverUrl: update.serverUrl !== void 0 ? normalizeServerUrl(update.serverUrl) : current.serverUrl,
      authorId: update.authorId !== void 0 ? normalizeAuthorId(update.authorId) : current.authorId
    };
  }
  async function loadSettings(store) {
    const raw = await store.get(["serverUrl", "authorId"]);
    let serverUrl = DEFAULT_SETTINGS.serverUrl;
    let authorId = DEFAULT_SETTINGS.authorId;
    try {
      if (typeof raw.serverUrl === "string") serverUrl = normalizeServerUrl(raw.serverUrl);
    } catch {
    }
    try {
      if (typeof raw.authorId === "string") authorId = normalizeAuthorId(raw.authorId);
    } catch {
    }
    return { serverUrl, authorId };
  }
  async function saveSettings(store, update) {
    const next = mergeSettings(await loadSettings(store), update);
    await store.set({ serverUrl: next.serverUrl, authorId: next.authorId });
    return next;
  }

  // src/background/api.ts
  var ApiError = class extends Error {
    /** HTTP status, or null when the server could not be reached at all. */
    constructor(message, status) {
      super(message);
      this.status = status;
      this.name = "ApiError";
    }
    status;
  };
  function describeServerError(body) {
    if (typeof body === "object" && body !== null && "error" in body) {
      const e = body.error;
      if (typeof e === "string") return e;
      if (e !== void 0) return JSON.stringify(e).slice(0, 300);
    }
    return "";
  }
  var CHANGE_TYPES = ["text", "style", "visibility", "script"];
  var isRecord2 = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
  function toLivePatch(raw) {
    if (!isRecord2(raw) || typeof raw.id !== "string" || !isRecord2(raw.change)) return null;
    const anchors = normalizeAnchor(raw.anchors);
    const c = raw.change;
    if (!anchors || typeof c.value !== "string" || typeof c.type !== "string" || !CHANGE_TYPES.includes(c.type)) return null;
    return {
      id: raw.id,
      target_url: typeof raw.target_url === "string" ? raw.target_url : "",
      anchors,
      change: { type: c.type, value: c.value }
    };
  }
  function createApi(deps) {
    const timeoutMs = deps.timeoutMs ?? 5e3;
    async function request(method, path, body) {
      const { serverUrl, authorId } = await deps.getSettings();
      const headers = { "x-actor-id": authorId };
      if (body !== void 0) headers["Content-Type"] = "application/json";
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      let res;
      try {
        res = await deps.fetch(serverUrl + path, {
          method,
          headers,
          body: body !== void 0 ? JSON.stringify(body) : void 0,
          cache: "no-store",
          signal: controller.signal
        });
      } catch {
        if (controller.signal.aborted) {
          throw new ApiError(`No answer from ${serverUrl} after ${Math.round(timeoutMs / 1e3)}s`, null);
        }
        throw new ApiError(`Cannot reach ${serverUrl}. Is the Patchwork server running?`, null);
      } finally {
        clearTimeout(timer);
      }
      const text = await res.text();
      let json;
      try {
        json = text ? JSON.parse(text) : void 0;
      } catch {
        json = void 0;
      }
      if (!res.ok) {
        const detail = describeServerError(json);
        throw new ApiError(`Server returned ${res.status}${detail ? `: ${detail}` : ""}`, res.status);
      }
      if (text && json === void 0) {
        throw new ApiError(`${serverUrl}${path} did not return JSON. Is this a Patchwork server?`, res.status);
      }
      return json;
    }
    return {
      request,
      /** GET /deployments/live. Patches with an unusable shape are dropped (and counted in `dropped`). */
      async liveState() {
        const body = await request("GET", "/deployments/live");
        if (!isRecord2(body) || !Array.isArray(body.patches) || typeof body.signature !== "string") {
          throw new ApiError("That address answered, but not with a Patchwork live deployment.", null);
        }
        const patches = body.patches.map(toLivePatch).filter((p) => p !== null);
        return { signature: body.signature, patches, dropped: body.patches.length - patches.length };
      },
      /** GET /deployments/live base version number. */
      async getBaseVersion() {
        try {
          const body = await request("GET", "/deployments/live");
          if (isRecord2(body) && isRecord2(body.version) && typeof body.version.number === "number") {
            return body.version.number;
          }
        } catch {
        }
        return 0;
      },
      /** POST /patches to create a draft patch. */
      async createPatch(patch) {
        const { authorId } = await deps.getSettings();
        const payload = {
          ...patch,
          author_id: patch.author_id || authorId
        };
        const res = await request("POST", "/patches", payload);
        if (!isRecord2(res) || typeof res.id !== "string") {
          throw new ApiError("Server response missing patch id", null);
        }
        return res;
      },
      /** GET /health. Rejects unless the answer looks like a Patchwork server. */
      async health() {
        const h = await request("GET", "/health");
        if (!h || h.ok !== true) throw new ApiError("That address answered, but it is not a Patchwork server.", null);
        return { ok: true, store: typeof h.store === "string" ? h.store : "unknown" };
      }
    };
  }

  // src/background/handlers.ts
  var STATUS_KEY = "connectionStatus";
  var PICK_KEY = "lastPick";
  function createHandler(deps) {
    const now = deps.now ?? Date.now;
    const getSettings = () => loadSettings(deps.local);
    const api = createApi({ getSettings, fetch: deps.fetch, timeoutMs: deps.timeoutMs });
    async function readCachedStatus() {
      const cached = (await deps.session.get([STATUS_KEY]))[STATUS_KEY];
      if (!isConnectionStatus(cached)) return null;
      return cached.serverUrl === (await getSettings()).serverUrl ? cached : null;
    }
    async function checkConnection() {
      const { serverUrl } = await getSettings();
      let status;
      try {
        const health = await api.health();
        status = { state: "connected", serverUrl, checkedAt: now(), store: health.store };
      } catch (e) {
        const error = e instanceof ApiError ? e.message : `Unexpected error: ${e instanceof Error ? e.message : String(e)}`;
        status = { state: "offline", serverUrl, checkedAt: now(), error };
      }
      await deps.session.set({ [STATUS_KEY]: status });
      return status;
    }
    const table = {
      GET_SETTINGS: () => getSettings(),
      SET_SETTINGS: async (m) => {
        const settings = await saveSettings(deps.local, m.settings);
        await deps.session.set({ [STATUS_KEY]: null });
        return settings;
      },
      CHECK_CONNECTION: () => checkConnection(),
      GET_CONNECTION_STATUS: () => readCachedStatus(),
      PICK_RESULT: async (m) => {
        const pick = normalizePick(m.pick);
        if (!pick) throw new Error("The picked element had no usable selector");
        await deps.session.set({ [PICK_KEY]: pick });
        return {};
      },
      GET_LAST_PICK: async () => normalizePick((await deps.session.get([PICK_KEY]))[PICK_KEY]),
      GET_LIVE_PATCHES: async () => {
        const { signature, patches, dropped } = await api.liveState();
        if (dropped > 0) console.warn(`[Patchwork] ignored ${dropped} live patch(es) with an unusable shape`);
        return { signature, patches };
      },
      GET_BASE_VERSION: async () => {
        const base_version = await api.getBaseVersion();
        return { base_version };
      },
      SAVE_DRAFT: async (m) => {
        const res = await api.createPatch({
          target_url: m.target_url,
          base_version: m.base_version,
          anchors: m.anchors,
          change: m.change,
          title: m.title
        });
        return { id: res.id, status: res.status, title: res.title };
      }
    };
    return (message) => table[message.type](message);
  }

  // src/background/index.ts
  var handle = createHandler({
    local: chromeStore(chrome.storage.local),
    session: chromeStore(chrome.storage.session),
    // Arrow wrapper: calling the bare global `fetch` as a method of another object throws "Illegal invocation".
    fetch: (input, init) => fetch(input, init)
  });
  chrome.runtime.onMessage.addListener((raw, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id) return false;
    const message = parseMessage(raw);
    if (!message) {
      sendResponse({ ok: false, error: "Unknown or malformed message" });
      return false;
    }
    handle(message).then(
      (data) => sendResponse({ ok: true, data }),
      (err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) })
    );
    return true;
  });
  if (chrome.sidePanel?.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((err) => console.warn("[Patchwork] could not enable side panel:", err));
  } else {
    void chrome.action.setPopup({ popup: "sidepanel.html" });
  }
  chrome.runtime.onInstalled.addListener((details) => {
    console.info("[Patchwork] background ready (" + details.reason + ")");
  });
})();
//# sourceMappingURL=background.js.map
