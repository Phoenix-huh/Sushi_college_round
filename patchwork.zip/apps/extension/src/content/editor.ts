// Stub editor
export {};
